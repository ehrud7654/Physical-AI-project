package com.anssa8bu.ssafy.event;

import static org.assertj.core.api.Assertions.*;

import com.anssa8bu.ssafy.event.application.*;
import com.anssa8bu.ssafy.event.entity.*;
import com.anssa8bu.ssafy.event.repository.OutboxEventRepository;
import java.time.*;
import java.util.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.redis.core.StringRedisTemplate;

@SpringBootTest(
    properties = {
      "app.outbox.enabled=false",
      "app.outbox.publisher-id=publisher-test",
      "app.outbox.batch-size=10",
      "app.outbox.lease-duration=50ms",
      "app.outbox.retention=1ms"
    })
class OutboxPublisherIntegrationTest {
  @Autowired OutboxEventRepository repo;
  @Autowired OutboxPublishService publisher;
  @Autowired OutboxClaimService claim;
  @Autowired OutboxCleanupService cleanup;
  @Autowired StringRedisTemplate redis;
  List<UUID> ids = new ArrayList<>();
  List<String> streamKeys = new ArrayList<>();

  @AfterEach
  void clean() {
    repo.deleteAllById(ids);
    redis.delete(streamKeys);
  }

  @Test
  void publishesToRedisStreamAndMarksPublished() {
    UUID owner = UUID.randomUUID();
    String key = "sse:events:" + owner;
    streamKeys.add(key);
    OutboxEvent e = save(Map.of("ownerId", owner.toString()));
    assertThat(publisher.publishBatch()).isPositive();
    OutboxEvent loaded = repo.findById(e.getId()).orElseThrow();
    assertThat(loaded.getStatus()).isEqualTo(OutboxStatus.PUBLISHED);
    assertThat(loaded.getPublishedAt()).isNotNull();
    assertThat(redis.opsForStream().size(key)).isOne();
  }

  @Test
  void dispatchFailureIsRescheduledWithoutPayloadInError() {
    OutboxEvent e = save(Map.of("safe", "value"));
    publisher.publishBatch();
    OutboxEvent loaded = repo.findById(e.getId()).orElseThrow();
    assertThat(loaded.getStatus()).isEqualTo(OutboxStatus.FAILED);
    assertThat(loaded.getAttempt()).isOne();
    assertThat(loaded.getLastError()).isEqualTo("IllegalArgumentException");
  }

  @Test
  void expiredClaimIsRecovered() {
    OutboxEvent e = save(Map.of("ownerId", UUID.randomUUID().toString()));
    assertThat(claim.claim()).contains(e.getId());
    try {
      Thread.sleep(80);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
    assertThat(claim.recoverExpired()).isPositive();
    assertThat(repo.findById(e.getId()).orElseThrow().getStatus()).isEqualTo(OutboxStatus.FAILED);
  }

  @Test
  void cleanupDeletesOnlyOldPublishedEvents() {
    UUID owner = UUID.randomUUID();
    streamKeys.add("sse:events:" + owner);
    OutboxEvent e = save(Map.of("ownerId", owner.toString()));
    publisher.publishBatch();
    try {
      Thread.sleep(10);
    } catch (InterruptedException ex) {
      Thread.currentThread().interrupt();
    }
    assertThat(cleanup.cleanupNow()).isOne();
    assertThat(repo.findById(e.getId())).isEmpty();
    ids.remove(e.getId());
  }

  private OutboxEvent save(Map<String, Object> payload) {
    UUID id = UUID.randomUUID();
    ids.add(id);
    return repo.saveAndFlush(
        new OutboxEvent(
            id,
            "pub-" + id,
            "TEST",
            id.toString(),
            "DONE",
            payload,
            Instant.now().minusSeconds(1)));
  }
}
