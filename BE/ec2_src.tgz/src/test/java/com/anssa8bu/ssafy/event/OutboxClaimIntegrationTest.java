package com.anssa8bu.ssafy.event;

import static org.assertj.core.api.Assertions.*;

import com.anssa8bu.ssafy.event.application.*;
import com.anssa8bu.ssafy.event.entity.*;
import com.anssa8bu.ssafy.event.repository.OutboxEventRepository;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.support.TransactionTemplate;

@SpringBootTest(
    properties = {
      "app.outbox.enabled=false",
      "app.outbox.publisher-id=test-publisher",
      "app.outbox.batch-size=1"
    })
class OutboxClaimIntegrationTest {
  @Autowired OutboxEventRepository repo;
  @Autowired OutboxClaimService claim;
  @Autowired TransactionTemplate tx;
  UUID id;

  @BeforeEach
  void seed() {
    id = UUID.randomUUID();
    repo.saveAndFlush(
        new OutboxEvent(
            id,
            "claim-" + id,
            "TEST",
            id.toString(),
            "READY",
            Map.of("ownerId", UUID.randomUUID().toString()),
            Instant.now().minusSeconds(1)));
  }

  @AfterEach
  void clean() {
    repo.deleteById(id);
  }

  @Test
  void concurrentPublishersClaimRowOnce() throws Exception {
    ExecutorService pool = Executors.newFixedThreadPool(2);
    try {
      var start = new CountDownLatch(1);
      Callable<List<UUID>> c =
          () -> {
            start.await();
            return claim.claim();
          };
      Future<List<UUID>> a = pool.submit(c), b = pool.submit(c);
      start.countDown();
      List<UUID> all = new ArrayList<>();
      all.addAll(a.get());
      all.addAll(b.get());
      assertThat(all).containsExactly(id);
      OutboxEvent loaded = repo.findById(id).orElseThrow();
      assertThat(loaded.getStatus()).isEqualTo(OutboxStatus.PROCESSING);
      assertThat(loaded.getAttempt()).isOne();
    } finally {
      pool.shutdownNow();
    }
  }
}
