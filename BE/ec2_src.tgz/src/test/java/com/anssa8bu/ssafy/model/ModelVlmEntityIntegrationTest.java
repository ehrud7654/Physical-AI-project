package com.anssa8bu.ssafy.model;

import static org.assertj.core.api.Assertions.assertThat;

import com.anssa8bu.ssafy.model.entity.RobotProfile;
import com.anssa8bu.ssafy.vlm.entity.*;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class ModelVlmEntityIntegrationTest {
  @Autowired EntityManager em;

  @Test
  @Transactional
  @Rollback
  void jsonUuidEnumNumericSurviveFlushClearAndRollback() {
    UUID profileId = UUID.randomUUID(), modelId = UUID.randomUUID(), policyId = UUID.randomUUID();
    Map<String, Object> camera = Map.of("names", List.of("front"));
    em.persist(
        new RobotProfile(
            profileId,
            "robot-" + profileId,
            "1.0",
            "arm",
            "ros2",
            "humble",
            camera,
            Map.of("joints", 6),
            Map.of("space", "joint")));
    em.persist(
        new VlmModelVersion(
            modelId, "test-" + modelId, "vlm", VlmModelStatus.CANDIDATE, Map.of("params", 7)));
    em.persist(new VlmPolicy(policyId, "policy-" + policyId, 1, new BigDecimal("0.7500"), true));
    em.flush();
    em.clear();
    assertThat(em.find(RobotProfile.class, profileId).getCameraContract()).isEqualTo(camera);
    assertThat(em.find(VlmModelVersion.class, modelId).getModelMetadata())
        .containsEntry("params", 7);
    assertThat(em.find(VlmPolicy.class, policyId).getConfidenceThreshold())
        .isEqualByComparingTo("0.7500");
  }
}
