package com.anssa8bu.ssafy.task.entity;

import jakarta.persistence.*;
import java.util.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "task_steps")
public class TaskStep {
  @Id private UUID id;

  @Column(name = "task_version_id", nullable = false)
  private UUID taskVersionId;

  @Column(name = "skill_version_id", nullable = false)
  private UUID skillVersionId;

  @Column(name = "step_order", nullable = false)
  private int stepOrder;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(nullable = false, columnDefinition = "jsonb")
  private Map<String, Object> parameters;

  @Column(name = "timeout_seconds")
  private Integer timeoutSeconds;

  protected TaskStep() {}

  public Map<String, Object> getParameters() {
    return parameters;
  }
}
