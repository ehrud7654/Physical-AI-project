package com.anssa8bu.ssafy.training.entity;

public enum TrainingJobStatus {
  CREATED,
  COLLECTING,
  INPUT_VALIDATING,
  INPUT_READY,
  QUEUED,
  PREPARING,
  RUNNING,
  MODEL_UPLOADING,
  MODEL_VALIDATING,
  CANCEL_REQUESTED,
  CANCELED,
  SUCCEEDED,
  FAILED
}
