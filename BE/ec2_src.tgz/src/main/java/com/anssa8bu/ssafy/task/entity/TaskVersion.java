package com.anssa8bu.ssafy.task.entity;

import com.anssa8bu.ssafy.common.entity.CreatedEntity;
import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "task_versions")
public class TaskVersion extends CreatedEntity {
  @Id private UUID id;

  @Column(name = "task_id", nullable = false)
  private UUID taskId;

  @Column(nullable = false)
  private int version;

  protected TaskVersion() {}

  public TaskVersion(UUID id, UUID taskId, int version) {
    if (version < 1) throw new IllegalArgumentException();
    this.id = id;
    this.taskId = taskId;
    this.version = version;
  }

  public UUID getId() {
    return id;
  }

  public int getVersion() {
    return version;
  }
}
