package com.anssa8bu.ssafy.vlm.entity;

import com.anssa8bu.ssafy.common.entity.CreatedEntity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.*;
import org.hibernate.annotations.*;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "vlm_inference_results")
public class VlmInferenceResult extends CreatedEntity {
  @Id private UUID id;

  @Column(name = "request_id", nullable = false, length = 150)
  private String requestId;

  @Column(name = "robot_id", nullable = false)
  private UUID robotId;

  @Column(name = "skill_id", nullable = false)
  private UUID skillId;

  @Column(name = "vlm_model_version_id")
  private UUID vlmModelVersionId;

  @Column(name = "vlm_policy_id", nullable = false)
  private UUID vlmPolicyId;

  @Column(name = "destination_key", nullable = false, length = 100)
  private String destinationKey;

  @Column(name = "target_description_ko", nullable = false, columnDefinition = "text")
  private String targetDescriptionKo;

  @Column(name = "bbox_x1", nullable = false, precision = 7, scale = 6)
  private BigDecimal bboxX1;

  @Column(name = "bbox_y1", nullable = false, precision = 7, scale = 6)
  private BigDecimal bboxY1;

  @Column(name = "bbox_x2", nullable = false, precision = 7, scale = 6)
  private BigDecimal bboxX2;

  @Column(name = "bbox_y2", nullable = false, precision = 7, scale = 6)
  private BigDecimal bboxY2;

  @Column(nullable = false, precision = 5, scale = 4)
  private BigDecimal confidence;

  @Column(name = "confidence_threshold", nullable = false, precision = 5, scale = 4)
  private BigDecimal confidenceThreshold;

  @Column(nullable = false)
  private boolean abstain;

  @Generated
  @Column(name = "motion_allowed", insertable = false, updatable = false)
  private boolean motionAllowed;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "raw_output", nullable = false, columnDefinition = "jsonb")
  private Map<String, Object> rawOutput;

  protected VlmInferenceResult() {}

  public boolean isMotionAllowed() {
    return motionAllowed;
  }
}
