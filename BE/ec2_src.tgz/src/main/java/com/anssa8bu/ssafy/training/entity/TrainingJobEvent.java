package com.anssa8bu.ssafy.training.entity;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.*;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

@Entity
@Table(name = "training_job_events")
public class TrainingJobEvent {
  @Id private UUID id;

  @Column(name = "training_job_id", nullable = false)
  private UUID trainingJobId;

  @Column(nullable = false)
  private int attempt;

  @Column(name = "event_id", nullable = false, length = 150)
  private String eventId;

  @Column(nullable = false)
  private long sequence;

  @Column(name = "event_type", nullable = false, length = 100)
  private String eventType;

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(nullable = false, columnDefinition = "jsonb")
  private Map<String, Object> payload;

  @Column(name = "occurred_at", nullable = false)
  private Instant occurredAt;

  @Column(name = "received_at", nullable = false)
  private Instant receivedAt;

  protected TrainingJobEvent() {}

  public TrainingJobEvent(
      UUID id,
      UUID jobId,
      int attempt,
      String eventId,
      long sequence,
      String type,
      Map<String, Object> payload,
      Instant occurred,
      Instant received) {
    this.id = id;
    this.trainingJobId = jobId;
    this.attempt = attempt;
    this.eventId = eventId;
    this.sequence = sequence;
    this.eventType = type;
    this.payload = Map.copyOf(payload);
    this.occurredAt = occurred;
    this.receivedAt = received;
  }

  public UUID getId() {
    return id;
  }

  public Map<String, Object> getPayload() {
    return payload;
  }
}
