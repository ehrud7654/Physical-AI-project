package com.anssa8bu.ssafy.vlm.entity;

import com.anssa8bu.ssafy.common.entity.CreatedEntity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.util.UUID;

@Entity
@Table(name = "vlm_policies")
public class VlmPolicy extends CreatedEntity {
  @Id private UUID id;

  @Column(name = "policy_key", nullable = false, length = 100)
  private String policyKey;

  @Column(nullable = false)
  private int version;

  @Column(name = "confidence_threshold", nullable = false, precision = 5, scale = 4)
  private BigDecimal confidenceThreshold;

  @Column(nullable = false)
  private boolean enabled;

  protected VlmPolicy() {}

  public VlmPolicy(UUID id, String key, int version, BigDecimal threshold, boolean enabled) {
    if (version < 1 || threshold.signum() < 0 || threshold.compareTo(BigDecimal.ONE) > 0)
      throw new IllegalArgumentException();
    this.id = id;
    policyKey = key;
    this.version = version;
    confidenceThreshold = threshold;
    this.enabled = enabled;
  }

  public UUID getId() {
    return id;
  }

  public BigDecimal getConfidenceThreshold() {
    return confidenceThreshold;
  }
}
