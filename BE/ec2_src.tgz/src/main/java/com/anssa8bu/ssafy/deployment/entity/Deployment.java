package com.anssa8bu.ssafy.deployment.entity;

import com.anssa8bu.ssafy.common.entity.AuditableEntity;
import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "deployments")
public class Deployment extends AuditableEntity {
  @Id private UUID id;

  @Column(name = "robot_id", nullable = false)
  private UUID robotId;

  @Column(name = "task_version_id", nullable = false)
  private UUID taskVersionId;

  @Enumerated(EnumType.STRING)
  @Column(nullable = false, length = 30)
  private DeploymentStatus status;

  @Column(name = "progress_percent", nullable = false, precision = 5, scale = 2)
  private BigDecimal progressPercent;

  @Column(name = "last_report_sequence", nullable = false)
  private long lastReportSequence;

  @Column(name = "error_code", length = 100)
  private String errorCode;

  @Column(name = "error_message", columnDefinition = "text")
  private String errorMessage;

  @Column(name = "applied_at")
  private Instant appliedAt;

  @Version
  @Column(name = "row_version", nullable = false)
  private Long rowVersion;

  protected Deployment() {}

  public Deployment(UUID id, UUID robot, UUID taskVersion) {
    this.id = id;
    robotId = robot;
    taskVersionId = taskVersion;
    status = DeploymentStatus.PENDING;
    progressPercent = BigDecimal.ZERO;
  }

  public UUID getId() {
    return id;
  }

  public DeploymentStatus getStatus() {
    return status;
  }

  public BigDecimal getProgressPercent() {
    return progressPercent;
  }

  public Long getRowVersion() {
    return rowVersion;
  }
}
