package com.anssa8bu.ssafy.event.application;

import com.anssa8bu.ssafy.event.config.OutboxProperties;
import com.anssa8bu.ssafy.event.repository.OutboxEventRepository;
import java.time.*;
import java.util.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OutboxClaimService {
  private final OutboxEventRepository repo;
  private final OutboxProperties props;
  private final Clock clock;

  public OutboxClaimService(OutboxEventRepository r, OutboxProperties p, Clock c) {
    repo = r;
    props = p;
    clock = c;
  }

  @Transactional
  public List<UUID> claim() {
    Instant now = clock.instant();
    List<UUID> ids = repo.lockPublishableIds(now, props.batchSize());
    repo.findAllById(ids).forEach(e -> e.claim(props.publisherId(), now, props.leaseDuration()));
    return ids;
  }

  @Transactional
  public int recoverExpired() {
    Instant now = clock.instant();
    List<UUID> ids = repo.lockExpiredIds(now, props.batchSize());
    repo.findAllById(ids).forEach(e -> e.recoverExpired(now));
    return ids.size();
  }
}
